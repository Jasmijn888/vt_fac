#!/bin/bash

# 加载必要的环境变量和路径设置
# shellcheck disable=SC1091
# . ./path.sh || exit 1;

# 定义要处理的数据集目录
data_sets=("hindi_source_dev" "hindi_source_eval" "hindi_source_train")

# 将第一个命令行参数赋值给 db_root 变量
db_root=$1

# 定义输出根目录
output_root="/scratch/s2615401/seq2seq-vc/egs/l2-arctic/cascade/data"
# 定义parse_textgrid.py的正确路径
parse_textgrid_script="/scratch/s2615401/seq2seq-vc/egs/l2-arctic/cascade/utils/parse_textgrid.py"

# 检查输入参数是否正确
if [ $# != 1 ]; then
    echo "Usage: $0 <db_root>"
    echo "e.g.: $0 /path/to/data_root"
    exit 1
fi

set -euo pipefail

# 遍历每个数据集
for data_set in "${data_sets[@]}"; do
    data_dir="${output_root}/${data_set}"
    
    # 创建输出目录（如果不存在）
    [ ! -e "${data_dir}" ] && mkdir -p "${data_dir}"

    # 设置文件路径
    scp="${data_dir}/wav.scp"
    segments="${data_dir}/segments"

    # 检查并删除旧文件
    [ -e "${scp}" ] && rm "${scp}"
    [ -e "${segments}" ] && rm "${segments}"

    # 获取当前数据集的音频和TextGrid目录
    wav_dir="${db_root}/${data_set}/wav"
    textgrid_dir="${db_root}/${data_set}/textgrid"

    # 生成 wav.scp 文件
    find "$(realpath ${wav_dir})" -name "*.wav" -follow | sort | while read -r filename; do
        id="$(basename "${filename}" | sed -e "s/\.[^\.]*$//g")"
        echo "${id} ${filename}" >> "${scp}"
    done

    # 生成 segments 文件
    python "${parse_textgrid_script}" --textgrid_dir "${textgrid_dir}" --output "${segments}"

    # 检查 wav.scp 和 segments 文件是否一致
    diff -q <(awk '{print $1}' "${scp}") <(awk '{print $1}' "${segments}") > /dev/null

    echo "Successfully prepared data for ${data_set}."
done

echo "All data sets have been processed."

